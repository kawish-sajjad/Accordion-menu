
$(document).ready(function(){
   
    $(".accordion").click(function(){
        if ($(this).next(".paragraph").css("display") != "block" ) {

            $(".paragraph").hide(400);
        }
        $(this).next(".paragraph").slideToggle(400);
    });
  
});